Welcome to the ChucK code examples from our Manning
book, "Introduction to Programming for Digital Artists,"

Just about all of the code shown in the book
can be found in various forms in this sample
source code that accompanies this book. The 
sample code can be downloaded free of charge 
from the Manning website at:

www.manning.com/ProgrammingforMusiciansandDigitalArtists

The accompanying sample code (including related audio files)
is installed automatically when you install ChucK. 

On a Mac it can be found in:
/Library/ChucK/examples/book/digital-artists/, 

while on Windows it is located at:
C:\Program Files\ChucK\examples\book\digital-artists\. 

On Linux, if you follow the installation procedure 
described in appendix A, the sample code can be found in:
/usr/local/share/doc/chuck/examples/book/digital-artists/

All of the sample code from this book can be accessed 
directly in miniAudicle by navigating to:

File > Open Example 
and locating book/digital-artists in the Example Browser.

NOTE: ChucK works on Mac OS X 10.5+ or later, Windows XP or later, or a
suitable Linux system.

Certain terms in text and code appear in color in
the eBook, and in the miniAudicle editor windows.
This is the miniAudicle recognizing those reserved 
words and coloring them by type.

Enjoy!  and Happy ChucKing!

Ajay, Perry, Spencer, and Ge


